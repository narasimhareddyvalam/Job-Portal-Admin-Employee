import React, { useState } from 'react';
import { TextField, Button, Box, Typography, CircularProgress, Container } from '@mui/material';
import axios from 'axios';
import { useSelector } from 'react-redux'; // To check if the user is admin

const AddCompany = () => {
  const [companyData, setCompanyData] = useState({
    name: '',
    description: '',
    imageUrl: '',
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const { type } = useSelector((state) => state.auth); // Check the user type (admin/employee)

  // Handle form input change
  const handleChange = (e) => {
    const { name, value } = e.target;
    setCompanyData((prevData) => ({ ...prevData, [name]: value }));
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const response = await axios.post('http://localhost:5001/companies', companyData);
      alert('Company added successfully!');
      setCompanyData({ name: '', description: '', imageUrl: '' }); // Reset form fields
    } catch (err) {
      setError('Error adding company. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // Check if the user is admin
  if (type !== 'admin') {
    return (
      <Box sx={{ padding: '2rem', textAlign: 'center', backgroundColor: '#f9f9f9' }}>
        <Typography variant="h5" color="error">
          You do not have permission to add companies.
        </Typography>
      </Box>
    );
  }

  return (
    <Box sx={{
      minHeight: '100vh', // Make sure it covers the full height
      backgroundColor: '#ffecd1',  // Light peach background to match homepage
      backgroundImage: 'linear-gradient(135deg, #ffecd1 0%, #fcb69f 100%)', // Gradient matching homepage
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      padding: '2rem',  // This padding ensures there is space around the form
    }}>
      <Container maxWidth="md">
        <Box sx={{
          padding: '2rem',
          maxWidth: '600px',
          margin: '0 auto',
          backgroundColor: 'white',  // White background for the form itself
          borderRadius: '8px',
          boxShadow: 3,
        }}>
          <Typography variant="h4" gutterBottom sx={{ color: '#e74c3c', fontWeight: 'bold' }}>
            Add New Company
          </Typography>
          {error && <Typography color="error" sx={{ marginBottom: '1rem' }}>{error}</Typography>}
          <form onSubmit={handleSubmit}>
            <TextField
              fullWidth
              label="Company Name"
              variant="outlined"
              name="name"
              value={companyData.name}
              onChange={handleChange}
              sx={{
                marginBottom: '1rem',
                backgroundColor: 'white',  // White background for input fields
              }}
            />
            <TextField
              fullWidth
              label="Company Description"
              variant="outlined"
              name="description"
              value={companyData.description}
              onChange={handleChange}
              sx={{
                marginBottom: '1rem',
                backgroundColor: 'white',  // White background for input fields
              }}
            />
            <TextField
              fullWidth
              label="Image URL"
              variant="outlined"
              name="imageUrl"
              value={companyData.imageUrl}
              onChange={handleChange}
              sx={{
                marginBottom: '1rem',
                backgroundColor: 'white',  // White background for input fields
              }}
            />
            <Button
              variant="contained"
              color="primary"
              type="submit"
              disabled={loading}
              sx={{
                width: '100%',
                padding: '12px 40px',
                backgroundColor: '#3498db',  // Primary blue like homepage button
                fontSize: '1.2rem',
                borderRadius: '50px',
                textTransform: 'none',
                boxShadow: 3,
                '&:hover': {
                  backgroundColor: '#2980b9',  // Darker blue on hover
                  boxShadow: 6,
                  transform: 'scale(1.05)',
                  transition: 'all 0.3s ease',
                }
              }}
            >
              {loading ? <CircularProgress size={24} sx={{ color: '#fff' }} /> : 'Add Company'}
            </Button>
          </form>
        </Box>
      </Container>
    </Box>
  );
};

export default AddCompany;
