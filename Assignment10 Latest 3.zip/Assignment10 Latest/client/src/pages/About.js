import React from 'react';
import { Typography, Box, Container, Grid } from '@mui/material';

const About = () => {
  return (
    <Box
      sx={{
        backgroundColor: '#ffecd1', // Soft peach background
        padding: '4rem 2rem',
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundImage: 'linear-gradient(135deg, #ffecd1 0%, #fcb69f 100%)', // Gradient background
      }}
    >
      <Container maxWidth="lg">
        <Grid container justifyContent="center">
          <Grid item xs={12} sm={10} md={8}>
            <Box
              sx={{
                textAlign: 'center',
                boxShadow: 3,
                padding: '3rem',
                borderRadius: '8px',
                backgroundColor: '#fff',
              }}
            >
              {/* Title */}
              <Typography
                variant="h3"
                sx={{
                  fontWeight: 700,
                  marginBottom: '1.5rem',
                  color: '#e74c3c', // Bright red color
                  fontSize: { xs: '2rem', sm: '3rem' },
                  textShadow: '2px 2px 5px rgba(0, 0, 0, 0.3)', // Subtle shadow for text
                }}
              >
                About Us
              </Typography>

              {/* Description */}
              <Typography
                variant="body1"
                sx={{
                  marginBottom: '2rem',
                  color: '#2c3e50', // Darker blue for contrast
                  fontSize: { xs: '1rem', sm: '1.2rem' },
                  lineHeight: 1.6,
                }}
              >
                Job Portal is your one-stop solution for connecting job seekers and employers. 
                Our mission is to streamline the hiring process while providing candidates with a wide range of job opportunities.
              </Typography>

              {/* Vision */}
              <Typography
                variant="h5"
                sx={{
                  fontWeight: 600,
                  color: '#e74c3c', // Matching color to the heading
                  marginBottom: '1rem',
                }}
              >
                Our Vision
              </Typography>
              <Typography
                variant="body1"
                sx={{
                  marginBottom: '1.5rem',
                  color: '#555',
                  lineHeight: 1.6,
                }}
              >
                Our vision is to become the leading platform where employers and employees connect seamlessly. 
                We aim to provide an innovative, user-friendly experience that benefits both job seekers and businesses.
              </Typography>

              {/* What We Offer */}
              <Typography
                variant="h5"
                sx={{
                  fontWeight: 600,
                  color: '#e74c3c', // Matching color to the heading
                  marginBottom: '1rem',
                }}
              >
                What We Offer
              </Typography>
              <Typography
                variant="body1"
                sx={{
                  marginBottom: '1.5rem',
                  color: '#555',
                  lineHeight: 1.6,
                }}
              >
                Job Portal offers an extensive range of services to both employers and job seekers:
                <ul>
                  <li>Job Listings: Explore thousands of job opportunities across various industries.</li>
                  <li>Employer Profiles: Create detailed company profiles to attract top talent.</li>
                  <li>Resume and Profile Management: Manage your professional profile and resume with ease.</li>
                  <li>Job Alerts: Get notified of new job postings based on your preferences.</li>
                </ul>
              </Typography>

              {/* Call to Action */}
              <Typography
                variant="h5"
                sx={{
                  fontWeight: 600,
                  color: '#e74c3c', // Matching color to the heading
                  marginBottom: '1rem',
                }}
              >
                Join Us Today
              </Typography>
              <Typography
                variant="body1"
                sx={{
                  color: '#555',
                  lineHeight: 1.6,
                }}
              >
                Join the Job Portal community and take your career or business to the next level. Whether you're looking for a job or the perfect candidate, we're here to help!
              </Typography>
            </Box>
          </Grid>
        </Grid>
      </Container>
    </Box>
  );
};

export default About;
