import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Box, Typography, Card, CardContent, Button, Grid, Paper } from '@mui/material';

const JobListings = () => {
  const [jobs, setJobs] = useState([]);

  useEffect(() => {
    const fetchJobs = async () => {
      const response = await axios.get('http://localhost:5001/jobs');
      setJobs(response.data);
    };
    fetchJobs();
  }, []);

  return (
    <Box
      sx={{
        padding: '4rem 2rem',
        backgroundColor: '#ffecd1', // Soft peach background matching homepage
        backgroundImage: 'linear-gradient(135deg, #ffecd1 0%, #fcb69f 100%)', // Gradient background
      }}
    >
      <Typography
        variant="h3"
        gutterBottom
        sx={{
          fontWeight: 700,
          textAlign: 'center',
          color: '#e74c3c', // Matching homepage red accent color for the title
          textShadow: '2px 2px 5px rgba(0, 0, 0, 0.3)', // Adding a subtle shadow for the heading
        }}
      >
        Job Listings
      </Typography>

      <Grid container spacing={3}>
        {jobs.map((job) => (
          <Grid item xs={12} sm={6} md={4} key={job._id}>
            <Paper elevation={3} sx={{ borderRadius: '8px' }}>
              <Card sx={{ display: 'flex', flexDirection: 'column', boxShadow: 3, borderRadius: '8px' }}>
                <CardContent sx={{ flexGrow: 1 }}>
                  <Typography variant="h5" sx={{ fontWeight: 'bold', color: '#e74c3c' }}>
                    {job.jobTitle}
                  </Typography>
                  <Typography variant="body2" sx={{ marginTop: '0.5rem', color: '#2c3e50' }}>
                    {job.description}
                  </Typography>
                  <Typography variant="body2" sx={{ marginTop: '1rem', fontStyle: 'italic', color: '#333' }}>
                    Salary: ${job.salary}
                  </Typography>
                  <Typography variant="body2" sx={{ marginTop: '0.5rem', color: '#2c3e50' }}>
                    Company: {job.companyName}
                  </Typography>

                  <Button
                    variant="contained"
                    color="secondary"
                    sx={{
                      marginTop: '1.5rem',
                      alignSelf: 'flex-start',
                      borderRadius: '20px',
                      padding: '8px 16px',
                      textTransform: 'none',
                      backgroundColor: '#3498db', // Matching homepage primary blue for the button
                      '&:hover': {
                        backgroundColor: '#2980b9', // Darker blue on hover
                      },
                    }}
                    href={job.applyLink || '#'}
                  >
                    Apply Now
                  </Button>
                </CardContent>
              </Card>
            </Paper>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
};

export default JobListings;
