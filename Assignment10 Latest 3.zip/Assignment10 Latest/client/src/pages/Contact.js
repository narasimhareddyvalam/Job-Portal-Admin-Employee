import React from 'react';
import { Box, Typography, TextField, Button, Container, Paper } from '@mui/material';

const Contact = () => {
  return (
    <Box
      sx={{
        padding: '4rem 2rem',
        backgroundColor: '#ffecd1', // Soft peach background matching homepage
        backgroundImage: 'linear-gradient(135deg, #ffecd1 0%, #fcb69f 100%)', // Gradient background
      }}
    >
      <Container maxWidth="sm">
        <Paper sx={{ padding: '2rem', boxShadow: 3, borderRadius: '8px', backgroundColor: '#fff' }}>
          <Typography
            variant="h3"
            sx={{
              fontWeight: 700,
              color: '#e74c3c', // Matching homepage red accent color
              textAlign: 'center',
              marginBottom: '2rem',
              textShadow: '2px 2px 5px rgba(0, 0, 0, 0.3)', // Adding subtle shadow for the heading
            }}
          >
            Contact Us
          </Typography>
          <Typography
            variant="body1"
            sx={{
              marginBottom: '1.5rem',
              color: '#2c3e50', // Darker text for contrast
              textAlign: 'center',
              lineHeight: 1.6,
            }}
          >
            Have questions or need assistance? We're here to help.
          </Typography>
          <form>
            <TextField
              fullWidth
              label="Your Name"
              variant="outlined"
              sx={{
                marginBottom: '1rem',
                '& .MuiInputLabel-root': { color: '#2c3e50' }, // Dark text for label
                '& .MuiOutlinedInput-root': {
                  '& fieldset': { borderColor: '#e74c3c' }, // Red border for input fields
                },
              }}
              required
            />
            <TextField
              fullWidth
              label="Your Email"
              variant="outlined"
              sx={{
                marginBottom: '1rem',
                '& .MuiInputLabel-root': { color: '#2c3e50' }, // Dark text for label
                '& .MuiOutlinedInput-root': {
                  '& fieldset': { borderColor: '#e74c3c' }, // Red border for input fields
                },
              }}
              required
              type="email"
            />
            <TextField
              fullWidth
              label="Your Message"
              variant="outlined"
              multiline
              rows={4}
              sx={{
                marginBottom: '1.5rem',
                '& .MuiInputLabel-root': { color: '#2c3e50' }, // Dark text for label
                '& .MuiOutlinedInput-root': {
                  '& fieldset': { borderColor: '#e74c3c' }, // Red border for input fields
                },
              }}
              required
            />
            <Button
              variant="contained"
              color="secondary"
              type="submit"
              fullWidth
              sx={{
                backgroundColor: '#3498db', // Primary blue for the button
                '&:hover': {
                  backgroundColor: '#2980b9', // Darker blue on hover
                },
                padding: '12px 0',
                borderRadius: '20px',
                textTransform: 'none',
                boxShadow: 2,
              }}
            >
              Submit
            </Button>
          </form>
        </Paper>
      </Container>
    </Box>
  );
};

export default Contact;
