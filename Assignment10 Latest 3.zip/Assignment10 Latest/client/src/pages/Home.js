import React from 'react';
import { Link } from 'react-router-dom';
import { Typography, Button, Box, Container } from '@mui/material';

const Home = () => {
  return (
    <Box
      sx={{
        backgroundColor: '#ffecd1', // Soft peach background
        padding: '4rem 2rem',
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundImage: 'linear-gradient(135deg, #ffecd1 0%, #fcb69f 100%)', // Gradient background
      }}
    >
      <Container maxWidth="md">
        <Box sx={{ textAlign: 'center' }}>
          {/* Heading */}
          <Typography
            variant="h3"
            sx={{
              fontWeight: 700,
              marginBottom: '1.5rem',
              color: '#e74c3c', // Bright red color
              fontSize: { xs: '2rem', sm: '3rem' },
              textShadow: '2px 2px 5px rgba(0, 0, 0, 0.3)', // Subtle shadow for text
            }}
          >
            Welcome to Job Portal
          </Typography>

          {/* Subheading */}
          <Typography
            variant="body1"
            sx={{
              marginBottom: '2rem',
              color: '#2c3e50', // Darker blue for contrast
              fontSize: { xs: '1rem', sm: '1.2rem' },
              lineHeight: 1.6,
            }}
          >
            Whether you're searching for your next opportunity or hiring top talent, we've got you covered. Browse job listings, company profiles, and connect with potential candidates to find the perfect match.
          </Typography>

          {/* Call to Action Button */}
          <Button
            variant="contained"
            color="secondary"
            size="large"
            component={Link}
            to="/job-listings"
            sx={{
              borderRadius: '50px',
              padding: '12px 40px',
              fontSize: { xs: '1rem', sm: '1.2rem' },
              textTransform: 'none',
              boxShadow: 3,
              backgroundColor: '#3498db', // Primary blue
              '&:hover': {
                backgroundColor: '#2980b9', // Darker blue on hover
                boxShadow: 6,
                transform: 'scale(1.05)',
                transition: 'all 0.3s ease',
              },
            }}
          >
            Explore Jobs
          </Button>

          {/* Additional content */}
          <Box sx={{ marginTop: '4rem', textAlign: 'center' }}>
            <Typography
              variant="h6"
              sx={{
                color: '#8e44ad', // Purple for section header
                fontWeight: 600,
                marginBottom: '1rem',
                fontSize: { xs: '1.1rem', sm: '1.3rem' },
              }}
            >
              Why Choose Us?
            </Typography>
            <Typography
              variant="body2"
              sx={{
                color: '#34495e', // Grey-blue text for description
                fontSize: { xs: '0.9rem', sm: '1rem' },
                lineHeight: 1.7,
                fontStyle: 'italic', // Slight italic for visual variety
              }}
            >
              Job Portal offers a seamless experience for both job seekers and employers. With a user-friendly interface, you can easily explore job listings, connect with employers, or post new jobs to find the best talent for your business.
            </Typography>
          </Box>

          {/* Footer (Optional, if you'd like more content at the bottom) */}
          <Box sx={{ marginTop: '4rem', textAlign: 'center' }}>
            <Typography
              variant="body2"
              sx={{
                color: '#2c3e50',
                fontSize: { xs: '0.8rem', sm: '1rem' },
              }}
            >
              Powered by Job Portal - Making the hiring process easy for everyone!
            </Typography>
          </Box>
        </Box>
      </Container>
    </Box>
  );
};

export default Home;
