import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Grid, Box, Typography, Card, CardMedia, CardContent, Paper } from '@mui/material';

const CompanyShowcase = () => {
  const [companies, setCompanies] = useState([]);

  useEffect(() => {
    const fetchCompanies = async () => {
      const response = await axios.get('http://localhost:5001/companies');
      setCompanies(response.data);
    };
    fetchCompanies();
  }, []);

  return (
    <Box
      sx={{
        padding: '4rem 2rem',
        backgroundColor: '#ffecd1', // Soft peach background matching homepage
        backgroundImage: 'linear-gradient(135deg, #ffecd1 0%, #fcb69f 100%)', // Gradient background
      }}
    >
      <Typography
        variant="h3"
        sx={{
          fontWeight: 700,
          color: '#e74c3c', // Matching homepage red accent color
          textAlign: 'center',
          marginBottom: '2rem',
          textShadow: '2px 2px 5px rgba(0, 0, 0, 0.3)', // Adding a subtle shadow to match homepage
        }}
      >
        Company Showcase
      </Typography>

      <Grid container spacing={3} justifyContent="center">
        {companies.map((company) => (
          <Grid item xs={12} sm={6} md={4} key={company.id}>
            <Paper elevation={3} sx={{ borderRadius: '8px', overflow: 'hidden' }}>
              <Card sx={{ display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
                <CardMedia
                  component="img"
                  height="200"
                  image={company.imageUrl || 'https://via.placeholder.com/200'}
                  alt={company.name}
                  sx={{ objectFit: 'cover' }}
                />
                <CardContent sx={{ textAlign: 'center', padding: '1rem' }}>
                  <Typography
                    variant="h6"
                    sx={{
                      fontWeight: 600,
                      color: '#e74c3c', // Using homepage red accent color for the company name
                      marginBottom: '0.5rem',
                    }}
                  >
                    {company.name}
                  </Typography>
                  <Typography
                    variant="body2"
                    sx={{
                      color: '#2c3e50', // Darker text for description for contrast
                      fontSize: '0.875rem',
                      lineHeight: 1.6,
                    }}
                  >
                    {company.description || 'No description available'}
                  </Typography>
                </CardContent>
              </Card>
            </Paper>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
};

export default CompanyShowcase;
