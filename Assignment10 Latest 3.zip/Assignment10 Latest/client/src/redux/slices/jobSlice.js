import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

export const fetchJobs = createAsyncThunk('jobs/fetchJobs', async () => {
  const response = await axios.get('http://localhost:5001/jobs');
  return response.data;
});

export const addJob = createAsyncThunk('jobs/addJob', async (jobData, { getState }) => {
  const { auth } = getState();
  const response = await axios.post('http://localhost:5001/admin/create/job', jobData, {
    headers: { Authorization: `Bearer ${auth.token}` },
  });
  return response.data;
});

const jobSlice = createSlice({
  name: 'jobs',
  initialState: {
    jobs: [],
    status: 'idle',
    error: null,
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchJobs.fulfilled, (state, action) => {
        state.jobs = action.payload;
        state.status = 'succeeded';
      })
      .addCase(fetchJobs.rejected, (state, action) => {
        state.error = action.error.message;
        state.status = 'failed';
      })
      .addCase(addJob.fulfilled, (state, action) => {
        state.jobs.push(action.payload);
      });
  },
});

export default jobSlice.reducer;
