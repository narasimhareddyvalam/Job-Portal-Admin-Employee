import React from 'react';
import { Link } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { logout } from '../../redux/slices/authSlice';
import { Navbar, Nav, Button, Container, Row, Col } from 'react-bootstrap';

const NavigationBar = () => {
  const { type, token, user } = useSelector((state) => state.auth);  // Assuming user has name or username in state
  const dispatch = useDispatch();

  return (
    <Navbar expand="lg" sticky="top" style={{ background: 'linear-gradient(90deg, #FFB6B9, #FF69B4)' }}>
      <Container>
        <Navbar.Brand as={Link} to="/" style={{ textDecoration: 'none', color: 'white' }}>
          {/* Optionally add brand name or logo */}
        </Navbar.Brand>
        
        <Navbar.Toggle aria-controls="navbar-nav" />
        <Navbar.Collapse id="navbar-nav">
          <Nav className="ml-auto">
            {/* Show these links only if the user is not an admin */}
            {type !== 'admin' && (
              <>
                <Nav.Link as={Link} to="/" style={{ color: '#FFFFFF' }}>
                  Home
                </Nav.Link>
                <Nav.Link as={Link} to="/about" style={{ color: '#FFFFFF' }}>
                  About
                </Nav.Link>
                <Nav.Link as={Link} to="/company-showcase" style={{ color: '#FFFFFF' }}>
                  Company Showcase
                </Nav.Link>
                <Nav.Link as={Link} to="/job-listings" style={{ color: '#FFFFFF' }}>
                  Jobs
                </Nav.Link>
                <Nav.Link as={Link} to="/contact" style={{ color: '#FFFFFF' }}>
                  Contact
                </Nav.Link>
              </>
            )}

            {/* Admin-specific links */}
            {type === 'admin' && (
              <Row className="g-2">
                <Col>
                  <Nav.Link as={Link} to="/admin/add-job" style={{ color: '#FFFFFF' }}>
                    Jobs
                  </Nav.Link>
                </Col>
                <Col>
                  <Nav.Link as={Link} to="/admin/employees" style={{ color: '#FFFFFF' }}>
                    Employees
                  </Nav.Link>
                </Col>
                <Col>
                  <Nav.Link as={Link} to="/admin/add-company" style={{ color: '#FFFFFF' }}>
                    Companies
                  </Nav.Link>
                </Col>
              </Row>
            )}

            {/* Employee-specific link */}
            {type === 'employee' && (
              <Nav.Link as={Link} to="/employee/jobs" style={{ color: '#FFFFFF' }}>
                My Jobs
              </Nav.Link>
            )}

            {/* Greeting */}
            {token && user && (
              <Nav.Link style={{ color: '#FFFFFF', fontSize: '1rem', marginTop: '8px' }}>
                Hey, {user.name || user.username} {/* Assuming the user object has 'name' or 'username' */}
              </Nav.Link>
            )}

            {/* Login/Register/Logout Buttons */}
            {!token ? (
              <>
                <Nav.Link as={Link} to="/login" style={{ color: '#FFFFFF' }}>
                  <Button variant="outline-light">Login</Button>
                </Nav.Link>
                <Nav.Link as={Link} to="/register" style={{ color: '#FFFFFF' }}>
                  <Button variant="outline-light">Register</Button>
                </Nav.Link>
              </>
            ) : (
              <Nav.Link as={Button} variant="outline-light" onClick={() => dispatch(logout())} style={{ marginLeft: 'auto' }}>
                Logout
              </Nav.Link>
            )}
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
};

export default NavigationBar;
