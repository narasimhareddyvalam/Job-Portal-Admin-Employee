import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchJobs } from '../../redux/slices/jobSlice';
import { Card, CardContent, CardActions, Typography, Grid, Button, CircularProgress, Container, Box } from '@mui/material';

const Jobs = () => {
  const dispatch = useDispatch();
  const { jobs, status } = useSelector((state) => state.jobs);

  useEffect(() => {
    dispatch(fetchJobs());
  }, [dispatch]);

  return (
    <Box
      sx={{
        minHeight: '100vh', // Full height to match the background gradient of the homepage
        backgroundColor: '#ffecd1',  // Light peach background
        backgroundImage: 'linear-gradient(135deg, #ffecd1 0%, #fcb69f 100%)', // Gradient effect similar to homepage
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        padding: '2rem',
      }}
    >
      <Container maxWidth="lg">
        <Typography
          variant="h4"
          gutterBottom
          align="center"
          sx={{
            color: '#e74c3c',  // Red color for heading, same as the homepage
            fontWeight: 'bold',
          }}
        >
          Available Jobs
        </Typography>

        {status === 'loading' && (
          <Grid container justifyContent="center" sx={{ marginTop: 4 }}>
            <CircularProgress />
          </Grid>
        )}

        {status === 'succeeded' && jobs.length === 0 && (
          <Typography variant="h6" color="textSecondary" align="center">
            No jobs available at the moment.
          </Typography>
        )}

        <Grid container spacing={4} justifyContent="center">
          {jobs.map((job) => (
            <Grid item xs={12} sm={6} md={4} key={job._id}>
              <Card sx={{ boxShadow: 3, borderRadius: '8px' }}>
                <CardContent>
                  <Typography variant="h6" gutterBottom sx={{ color: '#e74c3c' }}>
                    {job.jobTitle}
                  </Typography>
                  <Typography variant="body2" color="textSecondary" paragraph>
                    {job.description}
                  </Typography>
                  <Typography variant="body1" color="textPrimary">
                    Salary: ${job.salary}
                  </Typography>
                  <Typography variant="body2" color="textSecondary">
                    Company: {job.companyName}
                  </Typography>
                </CardContent>
                <CardActions>
                  <Button
                    size="small"
                    sx={{
                      backgroundColor: '#3498db',  // Blue color for button
                      color: 'white',
                      '&:hover': {
                        backgroundColor: '#2980b9',  // Darker blue on hover
                      },
                    }}
                  >
                    Apply
                  </Button>
                </CardActions>
              </Card>
            </Grid>
          ))}
        </Grid>
      </Container>
    </Box>
  );
};

export default Jobs;
