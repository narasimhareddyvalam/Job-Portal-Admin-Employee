import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { register } from '../../redux/slices/authSlice';
import { TextField, Button, Typography, Box, Paper, Grid, Container, MenuItem, Select, InputLabel, FormControl } from '@mui/material';
import { useNavigate } from 'react-router-dom'; // Importing useNavigate

const Register = () => {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    password: '',
    type: 'employee',
  });

  const dispatch = useDispatch();
  const navigate = useNavigate(); // Using useNavigate for programmatic navigation

  const handleSubmit = (e) => {
    e.preventDefault();
    dispatch(register(formData));
    alert('Registered successfully');
    navigate('/login'); // Navigate to the login page after successful registration
  };

  return (
    <Box
      sx={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        minHeight: '100vh',
        backgroundImage: 'linear-gradient(135deg, #ffecd1 0%, #fcb69f 100%)', // Full page gradient
        padding: '4rem 2rem',
      }}
    >
      <Container component="main" maxWidth="xs">
        <Paper sx={{ padding: 3, width: '100%', boxShadow: 3, borderRadius: '8px', backgroundColor: '#fff' }}>
          <Typography
            variant="h5"
            align="center"
            gutterBottom
            sx={{
              color: '#e74c3c', // Red color for the title
              textShadow: '2px 2px 5px rgba(0, 0, 0, 0.3)', // Subtle text shadow
            }}
          >
            Create an Account
          </Typography>
          <form onSubmit={handleSubmit}>
            <Grid container spacing={2}>
              {/* Full Name Field */}
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Full Name"
                  variant="outlined"
                  value={formData.fullName}
                  onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                  required
                  sx={{
                    '& .MuiInputLabel-root': { color: '#2c3e50' }, // Dark text for labels
                    '& .MuiOutlinedInput-root': {
                      '& fieldset': { borderColor: '#e74c3c' }, // Red border for input fields
                    },
                  }}
                />
              </Grid>

              {/* Email Field */}
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Email"
                  variant="outlined"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  required
                  sx={{
                    '& .MuiInputLabel-root': { color: '#2c3e50' }, // Dark text for labels
                    '& .MuiOutlinedInput-root': {
                      '& fieldset': { borderColor: '#e74c3c' }, // Red border for input fields
                    },
                  }}
                />
              </Grid>

              {/* Password Field */}
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Password"
                  variant="outlined"
                  type="password"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  required
                  sx={{
                    '& .MuiInputLabel-root': { color: '#2c3e50' }, // Dark text for labels
                    '& .MuiOutlinedInput-root': {
                      '& fieldset': { borderColor: '#e74c3c' }, // Red border for input fields
                    },
                  }}
                />
              </Grid>

              {/* Type Select */}
              <Grid item xs={12}>
                <FormControl fullWidth variant="outlined">
                  <InputLabel>Type</InputLabel>
                  <Select
                    value={formData.type}
                    onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                    label="Type"
                    sx={{
                      '& .MuiOutlinedInput-root': {
                        '& fieldset': { borderColor: '#e74c3c' }, // Red border for select fields
                      },
                    }}
                  >
                    <MenuItem value="employee">Employee</MenuItem>
                    <MenuItem value="admin">Admin</MenuItem>
                  </Select>
                </FormControl>
              </Grid>

              {/* Submit Button */}
              <Grid item xs={12}>
                <Button
                  type="submit"
                  fullWidth
                  variant="contained"
                  color="secondary"
                  sx={{
                    padding: '10px',
                    textTransform: 'none',
                    backgroundColor: '#3498db', // Blue color for the button
                    '&:hover': { backgroundColor: '#2980b9' }, // Darker blue on hover
                  }}
                >
                  Register
                </Button>
              </Grid>
            </Grid>
          </form>

          {/* Additional Information */}
          <Box sx={{ marginTop: '1.5rem', textAlign: 'center' }}>
            <Typography
              variant="body2"
              sx={{
                color: '#2c3e50', // Darker color for body text
                fontSize: '0.9rem',
              }}
            >
              Already have an account?{' '}
              <Button
                color="secondary"
                sx={{
                  textTransform: 'none',
                  fontSize: '0.9rem',
                  padding: 0,
                  '&:hover': { backgroundColor: 'transparent' }, // Transparent hover effect
                }}
                onClick={() => navigate('/login')}
              >
                Login here
              </Button>
            </Typography>
          </Box>
        </Paper>
      </Container>
    </Box>
  );
};

export default Register;
