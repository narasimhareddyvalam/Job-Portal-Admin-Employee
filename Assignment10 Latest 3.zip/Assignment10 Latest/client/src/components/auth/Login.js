import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { login } from '../../redux/slices/authSlice';
import { useNavigate } from 'react-router-dom';
import { TextField, Button, Typography, Box, Paper, Grid, Container } from '@mui/material';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { status, error } = useSelector((state) => state.auth);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const result = await dispatch(login({ email, password }));
    if (result.meta.requestStatus === 'fulfilled') {
      navigate('/');
    }
  };

  return (
    <Box
      sx={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        minHeight: '100vh',
        backgroundImage: 'linear-gradient(135deg, #ffecd1 0%, #fcb69f 100%)', // Full page gradient
        padding: '4rem 2rem',
      }}
    >
      <Container component="main" maxWidth="xs">
        <Paper sx={{ padding: 3, width: '100%', boxShadow: 3, borderRadius: '8px', backgroundColor: '#fff' }}>
          <Typography
            variant="h5"
            align="center"
            gutterBottom
            sx={{
              color: '#e74c3c', // Red color for the title matching the homepage
              textShadow: '2px 2px 5px rgba(0, 0, 0, 0.3)', // Adding subtle shadow for text
            }}
          >
            Login to Your Account
          </Typography>
          {status === 'failed' && (
            <Typography color="error" align="center" variant="body2">
              {error}
            </Typography>
          )}
          <form onSubmit={handleSubmit}>
            <Grid container spacing={2}>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Email"
                  variant="outlined"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  type="email"
                  required
                  autoFocus
                  sx={{
                    '& .MuiInputLabel-root': { color: '#2c3e50' }, // Dark text for labels
                    '& .MuiOutlinedInput-root': {
                      '& fieldset': { borderColor: '#e74c3c' }, // Red border for input fields
                    },
                  }}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Password"
                  variant="outlined"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  type="password"
                  required
                  sx={{
                    '& .MuiInputLabel-root': { color: '#2c3e50' }, // Dark text for labels
                    '& .MuiOutlinedInput-root': {
                      '& fieldset': { borderColor: '#e74c3c' }, // Red border for input fields
                    },
                  }}
                />
              </Grid>
              <Grid item xs={12}>
                <Button
                  type="submit"
                  fullWidth
                  variant="contained"
                  color="secondary"
                  sx={{
                    padding: '10px',
                    textTransform: 'none',
                    backgroundColor: '#3498db', // Blue color for the button
                    '&:hover': { backgroundColor: '#2980b9' }, // Darker blue on hover
                  }}
                >
                  Login
                </Button>
              </Grid>
            </Grid>
          </form>

          {/* Additional Information */}
          <Box sx={{ marginTop: '1.5rem', textAlign: 'center' }}>
            <Typography
              variant="body2"
              sx={{
                color: '#2c3e50', // Darker color for body text
                fontSize: '0.9rem',
              }}
            >
              New to Job Portal?{' '}
              <Button
                color="secondary"
                sx={{
                  textTransform: 'none',
                  fontSize: '0.9rem',
                  padding: 0,
                  '&:hover': { backgroundColor: 'transparent' }, // Transparent hover effect
                }}
                onClick={() => navigate('/register')}
              >
                Create an Account
              </Button>
            </Typography>
          </Box>
        </Paper>
      </Container>
    </Box>
  );
};

export default Login;
