import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { addJob } from '../../redux/slices/jobSlice';
import { TextField, Button, Typography, Box, Grid, Paper } from '@mui/material';

const AddJob = () => {
  const [jobData, setJobData] = useState({
    companyName: '',
    jobTitle: '',
    description: '',
    salary: '',
  });
  const dispatch = useDispatch();

  const handleSubmit = (e) => {
    e.preventDefault();
    dispatch(addJob(jobData));
    alert('Job added successfully');
  };

  return (
    <Box
      sx={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        minHeight: '100vh',
        backgroundImage: 'linear-gradient(135deg, #ffecd1 0%, #fcb69f 100%)', // Background gradient to match Register
        padding: '4rem 2rem',
      }}
    >
      <Paper
        sx={{
          padding: 3,
          width: 400,
          boxShadow: 3,
          borderRadius: '8px',
          backgroundColor: '#fff',
        }}
      >
        <Typography
          variant="h4"
          gutterBottom
          align="center"
          sx={{
            color: '#e74c3c', // Red color for title
            textShadow: '2px 2px 5px rgba(0, 0, 0, 0.3)', // Subtle text shadow for emphasis
          }}
        >
          Add Job
        </Typography>
        <form onSubmit={handleSubmit}>
          <Grid container spacing={2}>
            {/* Company Name Field */}
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Company Name"
                variant="outlined"
                value={jobData.companyName}
                onChange={(e) => setJobData({ ...jobData, companyName: e.target.value })}
                sx={{
                  '& .MuiInputLabel-root': { color: '#2c3e50' }, // Dark text for labels
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': { borderColor: '#e74c3c' }, // Red border for input fields
                  },
                }}
              />
            </Grid>

            {/* Job Title Field */}
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Job Title"
                variant="outlined"
                value={jobData.jobTitle}
                onChange={(e) => setJobData({ ...jobData, jobTitle: e.target.value })}
                sx={{
                  '& .MuiInputLabel-root': { color: '#2c3e50' }, // Dark text for labels
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': { borderColor: '#e74c3c' }, // Red border for input fields
                  },
                }}
              />
            </Grid>

            {/* Job Description Field */}
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Job Description"
                variant="outlined"
                multiline
                rows={4}
                value={jobData.description}
                onChange={(e) => setJobData({ ...jobData, description: e.target.value })}
                sx={{
                  '& .MuiInputLabel-root': { color: '#2c3e50' }, // Dark text for labels
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': { borderColor: '#e74c3c' }, // Red border for input fields
                  },
                }}
              />
            </Grid>

            {/* Salary Field */}
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Salary"
                variant="outlined"
                type="number"
                value={jobData.salary}
                onChange={(e) => setJobData({ ...jobData, salary: e.target.value })}
                sx={{
                  '& .MuiInputLabel-root': { color: '#2c3e50' }, // Dark text for labels
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': { borderColor: '#e74c3c' }, // Red border for input fields
                  },
                }}
              />
            </Grid>

            {/* Submit Button */}
            <Grid item xs={12}>
              <Button
                fullWidth
                variant="contained"
                color="secondary"
                type="submit"
                sx={{
                  padding: '10px',
                  textTransform: 'none',
                  backgroundColor: '#3498db', // Blue color for the button
                  '&:hover': { backgroundColor: '#2980b9' }, // Darker blue on hover
                }}
              >
                Add Job
              </Button>
            </Grid>
          </Grid>
        </form>
      </Paper>
    </Box>
  );
};

export default AddJob;
