import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Box, Typography, List, ListItem, ListItemText, Paper, Container, Grid } from '@mui/material';

const Employees = () => {
  const [employees, setEmployees] = useState([]);

  useEffect(() => {
    const fetchEmployees = async () => {
      const response = await axios.get('http://localhost:5001/admin/users');
      setEmployees(response.data);
    };
    fetchEmployees();
  }, []);

  return (
    <Box
      sx={{
        minHeight: '100vh', // Full height to match the background gradient of the homepage
        backgroundColor: '#ffecd1',  // Light peach background
        backgroundImage: 'linear-gradient(135deg, #ffecd1 0%, #fcb69f 100%)', // Gradient background similar to homepage
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        padding: '2rem',
      }}
    >
      <Container maxWidth="md">
        <Box
          sx={{
            padding: '2rem',
            backgroundColor: '#ffffff',  // White background for the content container
            borderRadius: '8px',
            boxShadow: 3,
          }}
        >
          <Typography
            variant="h4"
            gutterBottom
            sx={{
              color: '#e74c3c',  // Red color for heading, matches homepage theme
              fontWeight: 'bold',
            }}
          >
            All Employees
          </Typography>

          <Paper sx={{ padding: 3, boxShadow: 3, backgroundColor: '#ffffff' }}>
            <List sx={{ backgroundColor: '#f4f6f8' }}>  {/* Light grey background for the list */}
              {employees.map((employee) => (
                <ListItem
                  key={employee._id}
                  sx={{
                    borderBottom: '1px solid #ddd', // Subtle border between list items
                    padding: '1rem',
                  }}
                >
                  <Grid container spacing={2}>
                    <Grid item xs={12} sm={6}>
                      <ListItemText
                        primary={employee.fullName}
                        secondary="Full Name"
                        sx={{ color: '#333' }}  // Dark text color for readability
                      />
                    </Grid>
                    <Grid item xs={12} sm={6}>
                      <ListItemText
                        primary={employee.email}
                        secondary="Email"
                        sx={{ color: '#555' }}  // Slightly lighter text color for contrast
                      />
                    </Grid>
                  </Grid>
                </ListItem>
              ))}
            </List>
          </Paper>
        </Box>
      </Container>
    </Box>
  );
};

export default Employees;
