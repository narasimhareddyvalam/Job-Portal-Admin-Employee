import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import About from './pages/About';
import JobListings from './pages/JobListings';
import Contact from './pages/Contact';
import CompanyShowcase from './pages/CompanyShowcase';
import Login from './components/auth/Login';
import Register from './components/auth/Register';
import Jobs from './components/employee/Jobs';
import AddJob from './components/admin/AddJob';
import Employees from './components/admin/Employees';
import Navbar from './components/common/Navbar';
import AddCompany from '../src/pages/AddCompany';
import { useSelector } from 'react-redux';

const App = () => {
  const { type } = useSelector((state) => state.auth);

  return (
    <div>
      <Navbar />
      <Routes>
        {/* Public Routes */}
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/job-listings" element={<JobListings />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/company-showcase" element={<CompanyShowcase />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/admin/add-company" element={<AddCompany />} /> {/* Add this route */}

        {/* Admin Routes */}
        {type === 'admin' && (
          <>
            <Route path="/admin/add-job" element={<AddJob />} />
            <Route path="/admin/employees" element={<Employees />} />
          </>
        )}

        {/* Employee Routes */}
        {type === 'employee' && <Route path="/employee/jobs" element={<Jobs />} />}
      </Routes>
    </div>
  );
};

export default App;
