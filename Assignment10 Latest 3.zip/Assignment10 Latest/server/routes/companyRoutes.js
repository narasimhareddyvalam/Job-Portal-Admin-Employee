// routes/companyRoutes.js
const express = require('express');
const Company = require('../models/companyModel');
const router = express.Router();

// POST route to add a company
router.post('/', async (req, res) => {
  try {
    const { name, description, imageUrl } = req.body;

    const newCompany = new Company({ name, description, imageUrl });
    await newCompany.save();

    res.status(201).json(newCompany); // Respond with the newly created company
  } catch (error) {
    console.error('Error adding company:', error);
    res.status(500).json({ message: 'Failed to add company' });
  }
});

// GET route to fetch all companies
router.get('/', async (req, res) => {
  try {
    const companies = await Company.find();
    res.status(200).json(companies);
  } catch (error) {
    console.error('Error fetching companies:', error);
    res.status(500).json({ message: 'Failed to fetch companies' });
  }
});

module.exports = router;
