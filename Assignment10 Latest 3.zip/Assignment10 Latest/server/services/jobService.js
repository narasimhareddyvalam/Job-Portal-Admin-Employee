const Job = require('../models/jobModel');

exports.getAllJobs = async () => {
    return await Job.find();
};
