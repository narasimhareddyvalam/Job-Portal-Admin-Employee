const User = require('../models/userModel');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

exports.registerUser = async ({ fullName, email, password, type }) => {
    if (!['employee', 'admin'].includes(type)) throw new Error('Invalid user type');
    const hashedPassword = await bcrypt.hash(password, 10);
    const user = await User.create({ fullName, email, password: hashedPassword, type });
    return { message: 'User registered successfully', userId: user.id };
};

exports.loginUser = async ({ email, password }) => {
    const user = await User.findOne({ email });
    if (!user) throw new Error('User not found');

    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) throw new Error('Invalid credentials');

    const token = jwt.sign({ userId: user.id, type: user.type }, 'secretKey', { expiresIn: '1h' });
    return { message: 'Login successful', token, type: user.type };
};
