const Job = require('../models/jobModel');
const User = require('../models/userModel');

exports.addJob = async ({ companyName, jobTitle, description, salary }) => {
    return await Job.create({ companyName, jobTitle, description, salary });
};

exports.getAllUsers = async () => {
    return await User.find({}, '-password');
};
